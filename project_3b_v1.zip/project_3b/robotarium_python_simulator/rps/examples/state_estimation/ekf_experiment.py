import rps.robotarium as robotarium
from rps.utilities.transformations import *
from rps.utilities.barrier_certificates import *
from rps.utilities.misc import *
from rps.utilities.controllers import *
import argparse
import numpy as np
import time
from rps.utilities.uni_ekf import UnicycleEKF
import matplotlib.pyplot as plt

"""
Run Unicycle EKF experiment with the passed parameters.  All parameters have defaults if you don't want to mess with them.

Parameters:
    total_waypoints: int = 20,
    encoder_noise: list[float] = [0.01, 0.01], # right and left encoder count noise variance per step (counts^2); mapped to wheel angular velocity noise for EKF M
    process_noise: list[float] = [1.0, 1.0, 1.0], # x, y, and theta process noise variances, will be formed into matrix in code
    spoof_gps_measurements: bool = False, # whether to spoof GPS measurements
    gps_measurement_interval_distribution: float = (1.0, 1.0), # distribution of GPS measurement intervals (mean, std)
    gps_measurement_noise: list[float] = [0.1, 0.1], # x and y GPS measurement noise variances, will be formed into matrix in code
    use_imu_measurements: bool = False, # will arrive on every tick if true, otherwise not used
    imu_measurement_noise: list[float] = [0.01, 0.01, 0.01]): # acc_x, acc_y, and yaw rate IMU measurement noise variances, will be formed into matrix in code

Returns:
    None

Raises:
    ValueError: If the inputs are not valid
"""
def run_ekf_experiment(total_waypoints: int = 20,
                       process_noise: list[float] = [0.001, 0.001, 0.001], # x, y, and theta process noise variances, will be formed into matrix in code
                       spoof_gps_measurements: bool = False, # whether to spoof GPS measurements
                       gps_measurement_interval_distribution: float = (3.0, 1.0), # distribution of GPS measurement intervals (mean, std)
                       gps_measurement_noise: list[float] = [0.05, 0.05], # x and y GPS measurement noise variances, will be formed into matrix in code
                       use_imu_measurements: bool = False, # will arrive on every tick if true, otherwise not used
                       imu_measurement_noise: list[float] = [0.01, 0.01, 0.01]): # acc_x, acc_y, and yaw rate IMU measurement noise variances, will be formed into matrix in code

    N = 1 # using only one robot for now
    initial_conditions = np.array([[1.0], [0.0], [0.0]], dtype=float)
    r = robotarium.Robotarium(number_of_robots=N, show_figure=True, initial_conditions=initial_conditions,sim_in_real_time=True)

    goal_points = generate_initial_conditions(total_waypoints) # get random goal points

    # Create unicycle pose controller
    unicycle_pose_controller = create_hybrid_unicycle_pose_controller()

    # Create barrier certificates to avoid collision
    uni_barrier_cert = create_unicycle_barrier_certificate()

    # define x initially
    x = r.get_poses()
    r.step()

    wheel_radius = r.wheel_radius
    base_length = r.base_length
    dt = r.time_step

    # Map encoder count noise (variance per step) -> wheel angular velocity noise (rad/s)
    # delta_phi_noise = count_noise * counts_to_rad; omega_noise = delta_phi_noise / dt
    # => Var(omega_noise) = (counts_to_rad / dt)^2 * Var(count_noise)
    counts_to_rad = 2 * np.pi / (r.encoder_counts_per_revolution * r.motor_gear_ratio)
    encoder_ang_vel_var = (counts_to_rad / dt) ** 2 * (r.encoder_noise_std + 0.29) **2 # 0.29 is std from rounding of enocoder readings
    encoder_noise_matrix = np.eye(2) * encoder_ang_vel_var
    process_noise_matrix = np.eye(3) * np.array(process_noise)

    if spoof_gps_measurements:
        gps_measurement_noise_matrix = np.eye(2) * np.array(gps_measurement_noise)
    else:
        gps_measurement_noise_matrix = None

    if use_imu_measurements:
        imu_measurement_noise_matrix = np.eye(3) * np.array(imu_measurement_noise)
    else:
        imu_measurement_noise_matrix = None

    imu_measurement_noise_matrix = np.eye(3) * np.array(imu_measurement_noise)
    
    # Initialize EKF
    ekf = UnicycleEKF(initial_state=initial_conditions.flatten(), 
                initial_covariance=np.zeros((3, 3)), 
                b=base_length, 
                r=wheel_radius, 
                M=encoder_noise_matrix, 
                Q=process_noise_matrix, 
                R_gps=gps_measurement_noise_matrix, 
                R_imu=imu_measurement_noise_matrix)

    # Plotting setup
    gt_trail, = r.axes.plot([], [], 'b-', linewidth=1.5, label='Ground Truth')
    ekf_trail, = r.axes.plot([], [], 'r--', linewidth=1.5, label='EKF Estimate')
    gps_scatter = r.axes.scatter([], [], marker='x', s=80, c='green', linewidths=2, label=f'Spoofed GPS (std={np.sqrt(np.array(gps_measurement_noise))}, interval={gps_measurement_interval_distribution[0]:.1f} ± {gps_measurement_interval_distribution[1]:.1f} s)', zorder=5)
    r.axes.legend(loc='upper left', fontsize=6)

    gt_history = []
    ekf_history = []
    Pdiag_history = []
    gps_measurement_history = []

    # Live variance figure (separate from Robotarium axes)
    var_fig, var_axes = plt.subplots(3, 1, sharex=True, figsize=(7, 6))
    var_lines = [
        var_axes[0].plot([], [], label="Var(x)")[0],
        var_axes[1].plot([], [], label="Var(y)")[0],
        var_axes[2].plot([], [], label="Var(theta)")[0],
    ]
    var_axes[0].set_ylabel("Var(x)", fontsize=8)
    var_axes[1].set_ylabel("Var(y)", fontsize=8)
    var_axes[2].set_ylabel("Var(theta)", fontsize=8)
    var_axes[2].set_xlabel("time (s)", fontsize=8)
    var_fig.suptitle("EKF state variances (diag(P)) - live", fontsize=9)
    for ax in var_axes:
        ax.tick_params(axis='both', labelsize=7)
    var_fig.tight_layout()

    # Encoder deltas: get_encoders() returns (2, N) cumulative counts [left; right] since start
    counts_to_rad = 2 * np.pi / (r.encoder_counts_per_revolution * r.motor_gear_ratio)
    encoders_prev = r.get_encoders()

    current_time = time.time()
    next_gps_measurement_time = current_time + np.random.normal(gps_measurement_interval_distribution[0], gps_measurement_interval_distribution[1])
    for waypoint in goal_points.T: # while not all waypoints have been reached
        print(f"Next waypoint: {waypoint.reshape(3, 1)}")
        while at_pose(x, waypoint.reshape(3, 1))[0].size != N: # while not at the waypoint
            # Get poses of agents
            x = r.get_poses()
            encoders_curr = r.get_encoders()

            # Create unicycle control inputs (for robot motion)
            dxu = unicycle_pose_controller(x, waypoint.reshape(3, 1))
            dxu = uni_barrier_cert(dxu, x)

            current_time = time.time()
            if current_time >= next_gps_measurement_time:
                gps_measurement = x[:2, 0] + np.random.normal(0, np.sqrt(np.array(gps_measurement_noise)), 2)
                if spoof_gps_measurements:
                    ekf.update_gps(gps_measurement)
                gps_measurement_history.append(gps_measurement.copy())
                print(f"GPS measurement: {gps_measurement}")
                next_gps_measurement_time = current_time + np.random.normal(gps_measurement_interval_distribution[0], gps_measurement_interval_distribution[1])

            # v, w from encoder deltas (counts -> rad -> v, w) for EKF predict
            delta_counts_left = encoders_curr[0, 0] - encoders_prev[0, 0]
            delta_counts_right = encoders_curr[1, 0] - encoders_prev[1, 0]
            delta_phi_L = delta_counts_left * counts_to_rad
            delta_phi_R = delta_counts_right * counts_to_rad
            v_enc = (wheel_radius / 2) * (delta_phi_R + delta_phi_L) / dt
            w_enc = (wheel_radius / base_length) * (delta_phi_R - delta_phi_L) / dt

            ekf.predict(v_enc, w_enc, dt)
            encoders_prev = encoders_curr.copy()

            # Store trajectories
            gt_history.append(x[:2, 0].copy())
            ekf_history.append(ekf.state[:2].copy())
            Pdiag_history.append(np.diag(ekf.P).copy())   # [var_x, var_y, var_theta]

            # Update Robotarium trajectory plot
            gt_arr = np.array(gt_history)
            ekf_arr = np.array(ekf_history)
            gt_trail.set_data(gt_arr[:, 0], gt_arr[:, 1])
            ekf_trail.set_data(ekf_arr[:, 0], ekf_arr[:, 1])
            if len(gps_measurement_history) > 0:
                gps_scatter.set_offsets(np.array(gps_measurement_history))

            # Update live variance plot
            Pdiag_arr = np.asarray(Pdiag_history)
            t_arr = np.arange(Pdiag_arr.shape[0]) * dt
            for i in range(3):
                var_lines[i].set_data(t_arr, Pdiag_arr[:, i])
                var_axes[i].relim()
                var_axes[i].autoscale_view()
            var_fig.canvas.draw_idle()
            var_fig.canvas.flush_events()

            # Set the velocities
            r.set_velocities(np.arange(N), dxu)
            # Iterate the simulation
            r.step()

    # Call at end of script to print debug information and for your script to run on the Robotarium server properly
    np.savez('ekf_experiment_results.npz', gt_history=gt_history, ekf_history=ekf_history, Pdiag_history=Pdiag_history, gps_measurement_history=gps_measurement_history)
    r.call_at_scripts_end()

    # Summary plots: save variance figure and trajectory + GPS figure
    if len(gt_history) > 0:
        plt.ioff()
        var_fig.savefig('ekf_variances.png', dpi=150)
        gt_arr = np.array(gt_history)
        ekf_arr = np.array(ekf_history)
        fig, ax = plt.subplots(1, 1, figsize=(6, 6))
        ax.plot(gt_arr[:, 0], gt_arr[:, 1], 'b-', linewidth=1.5, label='Ground Truth')
        ax.plot(ekf_arr[:, 0], ekf_arr[:, 1], 'r--', linewidth=1.5, label='EKF Estimate')
        if len(gps_measurement_history) > 0:
            gps_arr = np.array(gps_measurement_history)
            ax.scatter(gps_arr[:, 0], gps_arr[:, 1], marker='x', s=80, c='green', linewidths=2, label='GPS', zorder=5)
        ax.set_xlabel('x (m)', fontsize=8)
        ax.set_ylabel('y (m)', fontsize=8)
        ax.legend(fontsize=7)
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.tick_params(axis='both', labelsize=7)
        fig.suptitle('Trajectory and GPS measurements', fontsize=9)
        fig.tight_layout()
        fig.savefig('ekf_trajectory_gps.png', dpi=150)
        plt.show(block=True)

def validate_inputs(total_waypoints: int, process_noise: np.ndarray, spoof_gps_measurements: bool, gps_measurement_interval_distribution: float, gps_measurement_noise: np.ndarray, use_imu_measurements: bool, imu_measurement_noise: np.ndarray):
    """ Validate the inputs to the run_ekf_experiment function """
    if total_waypoints < 1:
        raise ValueError("Total waypoints must be at least 1")
    if len(process_noise) != 3:
        raise ValueError("Process noise must be a list of length 3 with first being x process noise variance, second being y process noise variance, and third being theta process noise variance")
    if spoof_gps_measurements and (len(gps_measurement_noise) != 2):
        raise ValueError("GPS measurement noise must be a list of length 2 with first being x GPS measurement noise variance and second being y GPS measurement noise variance if GPS measurements are spoofed")
    if use_imu_measurements and (len(imu_measurement_noise) != 3):
        raise ValueError("IMU measurement noise must be a list of length 3 with first being acc_x measurement noise variance, second being acc_y measurement noise variance, and third being yaw rate measurement noise variance if IMU measurements are used")

def parse_args():
    """ Parse the command line arguments """
    parser = argparse.ArgumentParser(description="Run EKF experimentation")
    parser.add_argument("--total_waypoints", type=int, default=10, help="Total waypoints")
    parser.add_argument("--process_noise", type=float, nargs=3, default=[0.0001, 0.0001, 0.0001], help="Process noise (x, y, theta) as a list of three floats representing the x, y, and theta process noise variances")
    parser.add_argument("--spoof_gps_measurements", action='store_true', default=False, help="Whether to spoof GPS measurements")
    parser.add_argument("--gps_measurement_interval_distribution", type=float, nargs=2, default=[5.0, 2.5], help="GPS measurement interval distribution (mean, std) as a list")
    parser.add_argument("--gps_measurement_noise", type=float, nargs=2, default=[0.0001, 0.0001], help="GPS measurement noise (x, y) as a list")
    parser.add_argument("--use_imu_measurements", type=bool, default=False, help="Whether to use IMU measurements")
    parser.add_argument("--imu_measurement_noise", type=float, nargs=3, default=[0.01, 0.01, 0.01], help="IMU measurement noise (acc_x, acc_y, yaw rate) as a list")
    return parser.parse_args()

def main():
    args = parse_args()
    validate_inputs(args.total_waypoints, np.array(args.process_noise), args.spoof_gps_measurements, args.gps_measurement_interval_distribution, np.array(args.gps_measurement_noise), args.use_imu_measurements, np.array(args.imu_measurement_noise))
    print(f"Inputs validated, running EKF experiment with the following parameters:")
    print(f"Total waypoints: {args.total_waypoints}")
    print(f"Process noise: {args.process_noise}")
    print(f"Spoof GPS measurements: {args.spoof_gps_measurements}")
    print(f"GPS measurement interval distribution: {args.gps_measurement_interval_distribution}")
    print(f"GPS measurement noise: {args.gps_measurement_noise}")
    print(f"Use IMU measurements: {args.use_imu_measurements}")
    print(f"IMU measurement noise: {args.imu_measurement_noise}")
    print(f"Running EKF experiment...")
    run_ekf_experiment(args.total_waypoints,
                       args.process_noise,
                       args.spoof_gps_measurements,
                       args.gps_measurement_interval_distribution,
                       args.gps_measurement_noise,
                       args.use_imu_measurements,
                       args.imu_measurement_noise)


if __name__ == "__main__":
    main()